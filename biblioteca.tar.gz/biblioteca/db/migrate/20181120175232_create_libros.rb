class CreateLibros < ActiveRecord::Migration[5.2]
  def change
    create_table :libros do |t|
      t.string :title
      t.string :autor
      t.string :editorial
      t.string :num_pagina
      t.string :int

      t.timestamps
    end
  end
end
