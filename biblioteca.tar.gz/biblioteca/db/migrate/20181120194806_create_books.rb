class CreateBooks < ActiveRecord::Migration[5.2]
  def change
    create_table :books do |t|
      t.string :title
      t.string :autor
      t.string :editorial
      t.string :num_pagina

      t.timestamps
    end
  end
end
