class Libro < ApplicationRecord
	
	validates :title, :presence => true
	validates :autor, :presence => true
	validates :editorial, :presence =>true
	validates :num_paginas, :presence =>true
end
