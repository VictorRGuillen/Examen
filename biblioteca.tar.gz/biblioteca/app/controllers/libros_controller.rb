class LibrosController < ApplicationController
  def index
      @libros = Libro.all
  end
   def show
    @libros =Libro.find(params[:titulo])
  end

def new
    @libros = Libro.new
end
def create 
    @libros=Libro.new(title: params[:libros][:title],autor: params[:libros][:autor], editorial: params[:libros][:editorial], num_pagina: params[:libro][:num_pagina])
    if @libros.save
    	redirect_to @libros
    else
    	render:new
    end
end
def edit
  @libros = Libro.find(params[:titulo])
end
def update
  @libros = Libro.find(params[:titulo])
  if @libros.update(libros_params)
  else
    render:edit
  end
end
private def libros_params
	params.requiere(:libros).permit(:title,:autor,:editorial,:num_pagina)
end
end